1. The entrance of entire website is written in home.html
codes for the title and navgation bar is written in Reuse/head.js for reusing purpose,
and the same is for Reuse/footer.js. To change the title and footer, please go to the Reuse folder.
